#coding=utf-8
'''
Created on 2016.12.25
Top Quant-极宽量化分析系统
培训课件-配套教学python程序
@ www.TopQuant.vip      www.ziwang.com
'''
import numpy as np
import scipy as sp
import pandas as pd
import pip

# =======================

print('''新版本pip，get_installed_distributions()函数接口改了
      本案例取消
      开源项目，函数API接口，参数变化，属于很正常的现象
      包括，谷歌的TensorFlow，intel的openCV，还有pandas数据分析模块，
      每次大的版本升级，都会有个别函数API接口变化，
      这种因为版本变化，引发的程序代码冲突，称为：版本冲突
      所以，使用开源软件，要养成多动手搜索/查看最新版本的软件文档/函数接口餐宿
      ''')
#-----------------------
'''
#
x10=pip.get_installed_distributions();
df=pd.DataFrame();
df['name']=x10
print(df.head())

df.to_csv('tmp/m10.csv',index=False)
'''