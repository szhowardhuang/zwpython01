#coding=utf-8
'''
Created on 2016.12.25
Top Quant-极宽量化分析系统
培训课件-配套教学python程序
@ www.TopQuant.vip      www.ziwang.com
'''

import sys,os,re
import arrow,plotly


#------------------
#1
print('\n#1')
x=10
y=22
z=35
print('x,y,z,',x,y,z)

#2
print('\n#2')
a=x+y;print('a=x+y,',a)
b=x-y;print('b=x-y,',b)
c=z-x*y;print('c=z-x*y,',c)

#3
print('\n#3')
a=z/x;print('a=z/x,',a)
b=z//x;print('b=z//x,',b)
c=z%x;print('c=z%x,',c)

#4
print('\n#4')
a=x**2;print('a=x**2,',a)
b=x**3;print('b=x**3,',b)