#coding=utf-8
'''
Created on 2016.12.25
Top Quant-极宽量化分析系统
培训课件-配套教学python程序
@ www.TopQuant.vip      www.ziwang.com
'''

import sys,os,re
import arrow,plotly


#------------------

#1
print('\n#1')
zdict={}
zdict['w1']='hello'
zdict['w2']='ziwang.com'
print('zdict,',zdict)


#2
print('\n#2')
vdict={'url1':'TopQuant.vip'
       ,'url2':'www.TopQuant.vip'
       ,'url3':'ziwang.com'}
print('vdict,',vdict)


#3
print('\n#3')
s2=zdict['w1'];print('s2,',s2)
s3=vdict['url2'];print('s3,',s3)

