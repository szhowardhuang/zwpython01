#coding=utf-8
'''
Created on 2016.12.25
Top Quant-极宽量化分析系统
培训课件-配套教学python程序
@ www.TopQuant.vip      www.ziwang.com
'''
import os
import re
import pandas as pd
import numpy as np
import arrow

import requests
import bs4
from bs4 import BeautifulSoup 
from robobrowser import RoboBrowser 

import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib.font_manager import FontProperties 
import matplotlib.colors
from matplotlib import cm

import zwSys as zsys
import zwTools as zt
#

#-----------------------
def dr_cormap(fcor='dat/cormap.dat'):
    clst=zt.f_lstRdTxt(fcor);
    print('\n@clst',clst)
    ds=pd.Series(range(5,25));
    for xc,cor in enumerate(clst):
        css=cor
        xss='cm.'+css+'(np.linspace(0,1,10))'
        print(xc,'#',css,xss)
        cor2=eval(xss)
        #print(css,xss,cor2)
        ds.plot(kind='bar',rot=0,color=cor2) 
        plt.savefig('tmp/cm_'+css+'.png')
        

def dr_cors_sys():
    print('\n@dr_cors_sys')
    #
    ds=pd.Series(range(5,25));
    ds.plot(kind='bar',rot=0,color=zsys.cors_prism) 
    plt.savefig('tmp/prism.png')    
    #
    #ds.plot(kind='bar',rot=0,color=zsys.cors_brg) 
    #plt.savefig('tmp/brg.png')    
    #
    ds.plot(kind='bar',rot=0,color=zsys.cors_Dark2) 
    plt.savefig('tmp/dark2.png')    
    #
    ds.plot(kind='bar',rot=0,color=zsys.cors_hsv) 
    plt.savefig('tmp/hsv.png')    
    #
    ds.plot(kind='bar',rot=0,color=zsys.cors_jet) 
    plt.savefig('tmp/jet.png')    
     #
    ds.plot(kind='bar',rot=0,color=zsys.cors_hsv) 
    plt.savefig('tmp/hsv.png')    
     #
    ds.plot(kind='bar',rot=0,color=zsys.cors_hot) 
    plt.savefig('tmp/hot.png')    
    

#-----------------------
dr_cors_sys()

dr_cormap()

#------------
#
print('\nok,!')
