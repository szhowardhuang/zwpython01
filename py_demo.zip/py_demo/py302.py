#coding=utf-8
'''
Created on 2016.12.25
Top Quant-极宽量化分析系统
培训课件-配套教学python程序
@ www.TopQuant.vip      www.ziwang.com
'''

import sys,os,re
import arrow,plotly

import pandas as pd
import tushare as ts
import pygame

print("hello,zwPython 2017")
print("hello,TopQuant,TopFootball")
print("极宽量化回溯系统，极宽足彩量化分析系统")
print("")
print("python ver:",sys.version)
print("")
print("re ver:",re.__version__)
print("arrow:",arrow.__version__)
print("plotly:",plotly.__version__)
print("")
print("pandas ver:",pd.__version__)
print("tushare ver:",ts.__version__)
print("")
print("pygame ver:",pygame.ver)




